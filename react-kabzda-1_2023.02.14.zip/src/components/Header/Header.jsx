import React from 'react';
import classes from './Header.module.css'

const Header = () => {
  return (<header className={classes.header}>
      <img src='https://lisnyi.com/assets/images/logo-3.png' alt='logo'/>
    </header>)
}

export default Header;