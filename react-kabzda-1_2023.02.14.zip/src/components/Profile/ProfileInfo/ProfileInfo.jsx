import React from 'react';
import classes from './ProfileInfo.module.css'

const ProfileInfo = () => {
  return (
    <div>
        <img src='https://lisnyi.com/assets/images/mg-2256.webp' alt='content'/>
        <div className={classes.descriptionBlock}>ava + description</div>
    </div>
      )
} 

export default ProfileInfo;