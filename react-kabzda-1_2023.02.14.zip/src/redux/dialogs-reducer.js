const UPDATE_NEW_MESSAGE_TEXT ='UPDATE-NEW-MESSAGE-TEXT';
const SEND_MESSAGE = 'SEND-MESSAGE';

let initialState = {
  dialogData: [
          {id:1, name: "Vasya"},
          {id:2, name: "Andriy"},
          {id:3, name: "Yura"},
          {id:4, name: "Marta"},
          {id:5, name: "Olya"},
          {id:6, name: "Ivan"}
        ],
  messageData: [
          {id:1, message: "Hi"},
          {id:2, message: "How are you"},
          {id:3, message: "Yo"},
          {id:4, message: "Yo"},
          {id:5, message: "Yo"},
        ],
  newMessageText: '',
}

const dialogsReducer = (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_NEW_MESSAGE_TEXT:
      state.newMessageText = action.newText;
      return state;
    case SEND_MESSAGE:
      let text = state.newMessageText;
      state.newMessageText = '';
      state.messageData.push({id: 6, message: text});
      return state;
    default:
      return state;
  }
}
export const sendMessageCreator = () => ({type: SEND_MESSAGE})
export const updateNewMessageCreator = (text)=> {
  return {
    type: UPDATE_NEW_MESSAGE_TEXT,
    newText: text
  }
}

export default dialogsReducer;