import React from 'react';
// import classes from './ProfileInfo.module.css'
// import Preloader from '../../common/Preloader/Preloader'


class ProfileStatus extends React.Component {
  state = {
    editMode: false,
  }
  activateEditMode = ()=> {
    this.setState({
      editMode: true,
    })
  }
  deactivateEditMode = ()=> {
    this.setState({
      editMode: false,
    })
  }
  render() {
    return (
      <div>
        {!this.state.editMode && 
          <div>
            <span onDoubleClick={this.activateEditMode}>{this.props.status}</span>
          </div>
        }
        {this.state.editMode && 
          <div>
          <input autoFocus={true} onBlur={this.deactivateEditMode} value={this.props.status}/>
        </div>
        }
      </div>
    )
  }
} 

export default ProfileStatus;

// {
//   "aboutMe": "я круто чувак 1001%",
//   "contacts": {
//     "facebook": "facebook.com",
//     "website": null,
//     "vk": "vk.com/dimych",
//     "twitter": "https://twitter.com/@sdf",
//     "instagram": "instagra.com/sds",
//     "youtube": null,
//     "github": "github.com",
//     "mainLink": null
//   },
//   "lookingForAJob": true,
//   "lookingForAJobDescription": "не ищу, а дурачусь",
//   "fullName": "samurai dimych",
//   "userId": 2,
//   "photos": {
//     "small": "https://social-network.samuraijs.com/activecontent/images/users/2/user-small.jpg?v=0",
//     "large": "https://social-network.samuraijs.com/activecontent/images/users/2/user.jpg?v=0"
//   }
// }