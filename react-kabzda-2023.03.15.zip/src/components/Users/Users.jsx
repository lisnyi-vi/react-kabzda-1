import React from 'react';
import {NavLink} from "react-router-dom";
import classes from './Users.module.css';
import axios from 'axios';
import {usersAPI} from '../../api/api'



let Users = (props)=>  {
    let pagesCount = Math.ceil(props.totalUsersCount / props.pageSize)
    let pages =[];
    for(let i=1; i <= pagesCount; i++) {
      pages.push(i);
    }
    
    
    return (
      <div>
      <div>
        {pages.map(page => {
          return <span className={props.currentPage === page && classes.selectedPage} onClick={()=>{props.onPageChanged(page)}}>{page}</span>
        })}
      </div> 
      {  
        props.users.map(u => <div key={u.id}>
          <span>
            <div>
              <NavLink to={'/profile/' + u.id}>
              <img src ={u.photos.small != null ? u.photos.small : "https://upload.wikimedia.org/wikipedia/commons/4/41/Profile-720.png"} className={classes.userPhoto}/>
              </NavLink>
            </div>
            <div>
              {u.followed 
                ? <button disabled={props.followingInProgres.some(id=>id===u.id)} onClick={()=>{props.unfollow(u.id)}}>Unfollow</button>
                : <button disabled={props.followingInProgres.some(id=>id===u.id)} onClick={()=>{props.follow(u.id)}}>Follow</button>}
            </div>
          </span>
          <span>
            <span>
              <div>
                {u.name}
              </div>
              <div>
                {u.status}
              </div>
            </span>
            <span>
                <div>
                  {"u.location.city"}
                </div>
                <div>
                  {"u.location.country"}
                </div>
            </span>
          </span>
        </div>)
      }
    </div>  
    )
  }


export default Users;